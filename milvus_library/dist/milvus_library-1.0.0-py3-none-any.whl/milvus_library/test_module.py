def add_numbers(a, b):
    return a + b